#include <arpa/inet.h> 
#include <errno.h> 
#include <netinet/in.h> 
#include <signal.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <strings.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/select.h>
#include <sys/un.h>
#define PORT 5004
#define MAXLINE 1024 

int main() 
{ 
int sockfd; 
struct sockaddr_in servaddr; 

if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
printf("socket creation failed"); 
exit(0); 
} 

memset(&servaddr, 0, sizeof(servaddr)); 

servaddr.sin_family = AF_INET; 
servaddr.sin_port = htons(PORT); 
servaddr.sin_addr.s_addr = inet_addr("127.0.0.1"); 

if (connect(sockfd, (struct sockaddr*)&servaddr, 
sizeof(servaddr)) < 0) { 
printf("\n Error : Connect Failed \n"); 
} 

char buffer[1024];
fgets(buffer,sizeof(buffer),stdin);
write(sockfd, buffer, sizeof(buffer)); 

close(sockfd);
}